/** Resolve an exact player before messaging */
export function solve(input) {
  // TODO: implement the requirements without changing input.
  throw new Error("Not implemented");
}
