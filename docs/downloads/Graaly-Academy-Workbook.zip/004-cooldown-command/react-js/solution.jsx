/** A command with an exact cooldown */
export function solve(input) {
  // TODO: implement the requirements without changing input.
  throw new Error("Not implemented");
}

import React, { useMemo } from "react";
import { Message } from "@graaly/react";
export default function App({ input }) {
  const result = useMemo(() => solve(input), [input]);
  return <Message>{JSON.stringify(result)}</Message>;
}
