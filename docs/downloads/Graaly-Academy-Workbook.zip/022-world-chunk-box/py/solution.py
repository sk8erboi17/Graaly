# Enumerate every chunk intersecting a block box
from graaly_academy import *

def solve(input):
    # TODO: implement the requirements without changing input.
    raise NotImplementedError("Implement solve(input)")
