# Order scheduled callbacks deterministically
from graaly_academy import *

def solve(input):
    # TODO: implement the requirements without changing input.
    raise NotImplementedError("Implement solve(input)")
