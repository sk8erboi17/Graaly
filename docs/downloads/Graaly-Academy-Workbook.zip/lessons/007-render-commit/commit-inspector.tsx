import React, { useState } from "react";
import { createRoot, Inventory, Item, Line, Scoreboard } from "@graaly/react";
import { player } from "./fixture";

function App() {
  const [count, setCount] = useState(0);
  return <>
    <Scoreboard title="Inspector"><Line id="count">{count}</Line></Scoreboard>
    <Inventory title="Actions" rows={3}><Item slot={13} material="LEVER"
      name="Commit" onClick={() => setCount(value => value + 1)} /></Inventory>
  </>;
}
const root = createRoot(player, { inspect: true, history: 50 });
root.subscribe(commit => console.log(commit.operations));
root.render(<App />);