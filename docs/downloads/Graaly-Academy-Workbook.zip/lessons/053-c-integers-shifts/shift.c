#include <stdbool.h>
#include <stdint.h>
#include <graaly/bits.h>

uint64_t logical_left(uint64_t value, unsigned count) {
    return count < 64u ? value << count : UINT64_C(0);
}
bool flag32(unsigned bit, uint32_t *out) {
    return graaly_u32_shift_left(UINT32_C(1), bit, out);
}
