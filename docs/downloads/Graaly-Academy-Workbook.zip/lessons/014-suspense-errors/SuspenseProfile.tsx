import React, { Suspense, use } from "react";
import { Line, Message, Scoreboard } from "@graaly/react";

type Profile = { name: string; coins: number };
const profilePromise: Promise<Profile> = Promise.resolve({ name: "Alex", coins: 150 });
function Profile() {
  const profile = use(profilePromise);
  return <Scoreboard title="Profile"><Line id="coins">{profile.name}: {profile.coins}</Line></Scoreboard>;
}
export default function App() {
  return <Suspense fallback={<Message>&eLoading profile...</Message>}><Profile /></Suspense>;
}