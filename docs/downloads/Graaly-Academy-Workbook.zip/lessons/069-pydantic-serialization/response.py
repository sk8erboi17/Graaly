from decimal import Decimal
from pydantic import BaseModel, SecretStr, computed_field

class InternalOrder(BaseModel):
    token: SecretStr
    price: Decimal
    quantity: int

class PublicOrder(BaseModel):
    price: Decimal
    quantity: int
    @computed_field
    @property
    def total(self) -> Decimal:
        return self.price * self.quantity

public = PublicOrder(price=Decimal("1.25"), quantity=2).model_dump(mode="json")
assert public["total"] == "2.50" and "token" not in public
