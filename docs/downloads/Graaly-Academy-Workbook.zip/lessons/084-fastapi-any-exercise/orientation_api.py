from typing import Any
from fastapi import FastAPI, Body
app = FastAPI()

def solve(value):
    return {"yaw": value["yaw"] % 360,
            "pitch": min(90, max(-90, value["pitch"]))}

@app.post("/solve")
async def endpoint(value: Any = Body(...)):
    return solve(value)
