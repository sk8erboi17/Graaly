npx tsc --noEmit
npm run build
test -f dist/main.mjs
