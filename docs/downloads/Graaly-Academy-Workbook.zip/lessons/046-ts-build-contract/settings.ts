type Policy = { retry: number; mode: "safe" | "fast" };
export const policy = { retry: 3, mode: "safe" } satisfies Policy;
