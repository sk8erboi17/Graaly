import { packets, ServerPacket, WrapperPlayServerUpdateHealth } from "graaly";
packets.onSend(ServerPacket.UPDATE_HEALTH, ctx => {
  const packet = ctx.wrap(WrapperPlayServerUpdateHealth);
  if (packet.health > 20) {
    packet.health = 20;
    ctx.reencode();
  }
});
