import React, { useReducer } from "react";
import { Inventory, Item, Line, Scoreboard } from "@graaly/react";

type State = { quantities: Record<string, number> };
type Action = { type: "added"; id: string } | { type: "cleared" };
function reducer(state: State, action: Action): State {
  if (action.type === "cleared") return { quantities: {} };
  return { quantities: { ...state.quantities,
    [action.id]: (state.quantities[action.id] ?? 0) + 1 } };
}
export default function Cart() {
  const [state, dispatch] = useReducer(reducer, { quantities: {} });
  const total = Object.values(state.quantities).reduce((sum, value) => sum + value, 0);
  return <>
    <Scoreboard title="Cart"><Line id="total">Items: {total}</Line></Scoreboard>
    <Inventory title="Shop" rows={3}><Item slot={13} material="DIAMOND"
      name="Add diamond" onClick={() => dispatch({ type: "added", id: "diamond" })} /></Inventory>
  </>;
}