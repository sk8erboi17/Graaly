import asyncio

async def ordered(values, worker):
    async with asyncio.TaskGroup() as group:
        tasks = [group.create_task(worker(value)) for value in values]
    return [task.result() for task in tasks]

async def worker(value):
    await asyncio.sleep(0)
    return value * 2
