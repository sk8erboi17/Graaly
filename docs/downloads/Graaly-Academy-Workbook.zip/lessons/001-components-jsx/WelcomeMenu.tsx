import React, { type PropsWithChildren } from "react";
import { Inventory, Item, Message } from "@graaly/react";

type ShellProps = PropsWithChildren<{ title: string }>;

function MenuShell({ title, children }: ShellProps) {
  return <Inventory id="academy" title={title} rows={3}>{children}</Inventory>;
}

export default function WelcomeMenu() {
  return (
    <>
      <Message id="hello">&aAcademy opened</Message>
      <MenuShell title="Choose a lesson">
        <Item slot={13} material="BOOK" name="&aReact foundations" />
      </MenuShell>
    </>
  );
}