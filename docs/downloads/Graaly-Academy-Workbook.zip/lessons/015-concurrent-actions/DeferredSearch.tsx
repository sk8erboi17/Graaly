import React, { useDeferredValue, useState } from "react";
import { ChatInput, Inventory, Item } from "@graaly/react";

const modes = ["Factions", "KitPvP", "Prison", "Survival"];
export default function Search() {
  const [query, setQuery] = useState("");
  const deferred = useDeferredValue(query);
  const visible = modes.filter(mode => mode.toLowerCase().includes(deferred.toLowerCase()));
  return <>
    <ChatInput prompt="Search a mode" value={query} onChange={setQuery} />
    <Inventory title="Results" rows={3}>{visible.map((mode, index) =>
      <Item key={mode} slot={10 + index * 2} material="COMPASS" name={mode} />
    )}</Inventory>
  </>;
}