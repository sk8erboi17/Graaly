import React, { Profiler, memo, useMemo, useState } from "react";
import { Inventory, Item, Line, Scoreboard } from "@graaly/react";

const Stats = memo(({ values }: { values: number[] }) =>
  <Scoreboard title="Stats"><Line id="sum">Total: {values.reduce((a, b) => a + b, 0)}</Line></Scoreboard>
);
export default function App() {
  const [count, setCount] = useState(0);
  const values = useMemo(() => [10, 20, 30], []);
  return <Profiler id="academy" onRender={() => {}}>
    <Stats values={values} />
    <Inventory title="Counter" rows={3}><Item slot={13} material="REDSTONE"
      name={"Clicks " + count} onClick={() => setCount(value => value + 1)} /></Inventory>
  </Profiler>;
}