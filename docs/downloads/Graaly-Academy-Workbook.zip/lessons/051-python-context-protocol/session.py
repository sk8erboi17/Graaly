from contextlib import asynccontextmanager
from typing import Protocol

class Ledger(Protocol):
    async def close(self) -> None: ...

@asynccontextmanager
async def owned_session(open_session):
    session: Ledger = await open_session()
    try:
        yield session
    finally:
        await session.close()
