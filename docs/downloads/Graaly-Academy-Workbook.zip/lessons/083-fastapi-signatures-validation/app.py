from typing import Annotated
from fastapi import FastAPI, Query, HTTPException
from pydantic import BaseModel
app = FastAPI()

class Item(BaseModel):
    sku: str
    price_cents: int

@app.get("/items/{sku}", response_model=Item)
async def item(sku: str, quantity: Annotated[int, Query(ge=1, le=64)] = 1):
    if sku != "stone": raise HTTPException(404, "Unknown SKU")
    return {"sku": sku, "price_cents": 25 * quantity, "internal_token": "private"}
