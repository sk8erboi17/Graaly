import pytest
from httpx import ASGITransport, AsyncClient

@pytest.mark.anyio
async def test_retry_is_idempotent(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        command = {"item": "diamond"}
        headers = {**AUTH, "Idempotency-Key": "same-purchase-key"}
        first = await client.post("/v1/shop/purchase", json=command, headers=headers)
        retry = await client.post("/v1/shop/purchase", json=command, headers=headers)
    assert retry.json() == first.json()
    assert (await profile(app, "p1")).purchases == 1