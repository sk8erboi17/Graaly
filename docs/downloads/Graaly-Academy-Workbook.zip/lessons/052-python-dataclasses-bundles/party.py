from dataclasses import dataclass, field, replace

@dataclass
class Party:
    name: str
    members: list[str] = field(default_factory=list)

def normalized(party: Party) -> Party:
    return replace(party, name=party.name.strip(), members=list(party.members))

first, second = Party("One"), Party("Two")
first.members.append("Alex")
assert second.members == []
