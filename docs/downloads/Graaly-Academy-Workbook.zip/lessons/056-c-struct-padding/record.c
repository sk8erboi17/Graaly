#include <stddef.h>
#include <stdint.h>

typedef struct { uint8_t tag; uint32_t counter; uint16_t flags; } Record;
int equal_record(const Record *a, const Record *b) {
    return a->tag == b->tag && a->counter == b->counter && a->flags == b->flags;
}
size_t record_padding(void) {
    return sizeof(Record) - sizeof(uint8_t) - sizeof(uint32_t) - sizeof(uint16_t);
}
size_t counter_offset(void) { return offsetof(Record, counter); }
