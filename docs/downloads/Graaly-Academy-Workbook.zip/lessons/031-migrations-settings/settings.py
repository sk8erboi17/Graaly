from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="GRAALY_", env_file=".env")
    database_url: str
    jwt_secret: str = Field(min_length=32)
    token_ttl_seconds: int = Field(default=300, ge=30, le=3600)
    auto_create_schema: bool = False

# deploy: alembic upgrade head
# start:  uvicorn app.main:app