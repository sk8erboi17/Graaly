#include <stdint.h>
#include <string.h>
typedef enum { MOVE = 1, CHAT = 2 } Kind;
typedef struct {
    Kind kind;
    union { struct { int x, z; } move; unsigned chat_length; } data;
} Packet;
int payload_size(const Packet *packet) {
    switch (packet->kind) {
        case MOVE: return 8;
        case CHAT: return (int)packet->data.chat_length;
        default: return -1;
    }
}
uint32_t float_bits(float value) {
    _Static_assert(sizeof(float) == sizeof(uint32_t), "32-bit float required");
    uint32_t bits; memcpy(&bits, &value, sizeof bits); return bits;
}
