import React from "react";
import { createPortal, Message, type GraalyRoot } from "@graaly/react";

export function StaffAlert({ staffRoot, text }: { staffRoot: GraalyRoot; text: string }) {
  return createPortal(<Message id="staff-alert">&c{text}</Message>, staffRoot);
}