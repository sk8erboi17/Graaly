type Brand<T, Name extends string> = T & { readonly __brand: Name };
type PlayerId = Brand<string, "PlayerId">;
type Permission = "profile.read" | "profile.write" | "shop.read" | "shop.purchase";
type Result<T, E> = { ok: true; value: T } | { ok: false; error: E };
type ReadonlyApi<T> = { readonly [K in keyof T]: Awaited<T[K]> };

const prices = { diamond: 40, gold: 25 }
  satisfies Record<"diamond" | "gold", number>;

async function load(id: PlayerId, signal: AbortSignal): Promise<Result<Profile, Error>> {
  try { return { ok: true, value: await api.profile(id, { signal }) }; }
  catch (error: unknown) {
    return { ok: false, error: error instanceof Error ? error : new Error(String(error)) };
  }
}