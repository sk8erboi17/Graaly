package example;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class ThreadBoundary {
    public static void notifyLater(Plugin plugin, Player player, String message) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (plugin.isEnabled() && player.isOnline()) player.sendMessage(message);
        });
    }
}
