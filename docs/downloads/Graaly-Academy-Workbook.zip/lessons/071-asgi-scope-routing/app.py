async def app(scope, receive, send):
    if scope["type"] != "http":
        raise RuntimeError("This example supports HTTP only")
    ready = scope["method"] == "GET" and scope["path"] == "/health"
    await send({"type": "http.response.start", "status": 200 if ready else 404,
                "headers": [(b"content-type", b"application/json")]})
    await send({"type": "http.response.body",
                "body": b'{"ready":true}' if ready else b'{"detail":"Not found"}',
                "more_body": False})
