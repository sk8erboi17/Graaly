BEGIN;
UPDATE items SET stock = stock - 2
WHERE sku = 'stone' AND stock >= 2;
-- The service checks the affected-row count before inserting an order.
-- COMMIT after all required writes; ROLLBACK on any failure.
ROLLBACK;
SELECT sku, stock FROM items ORDER BY sku;
