import type { components } from "./api/generated-schema";
type Purchase = components["schemas"]["PurchaseResponse"];

type State =
  | { status: "idle" }
  | { status: "pending"; requestId: string }
  | { status: "ready"; result: Purchase }
  | { status: "error"; error: Error };

function assertNever(value: never): never {
  throw new Error("Unhandled state: " + JSON.stringify(value));
}