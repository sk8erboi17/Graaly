import { useEffect, useState } from "react";
import { api } from "../api";

export function useProfile(playerId: string) {
  const [state, setState] = useState({ status: "loading", profile: null });
  useEffect(() => {
    let ignore = false;
    setState({ status: "loading", profile: null });
    api.profile(playerId).then(profile => {
      if (!ignore) setState({ status: "ready", profile });
    });
    return () => { ignore = true; };
  }, [playerId]);
  return state;
}