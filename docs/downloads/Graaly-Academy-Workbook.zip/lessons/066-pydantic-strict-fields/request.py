from pydantic import BaseModel, ConfigDict, Field

class Purchase(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    player: str = Field(min_length=3, max_length=16)
    quantity: int = Field(ge=1, le=64)

request = Purchase.model_validate({"player": "Alex", "quantity": 2})
assert request.quantity == 2
