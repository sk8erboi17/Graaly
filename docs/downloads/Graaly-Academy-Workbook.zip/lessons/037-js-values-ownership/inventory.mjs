export function normalized(stacks) {
  return stacks.map(stack => ({
    ...stack,
    lore: [...(stack.lore ?? [])],
  })).sort((a, b) => a.slot - b.slot);
}
const input = [{ slot: 4, lore: ["Owned by caller"] }];
const result = normalized(input);
result[0].lore.push("Preview only");
console.assert(input[0].lore.length === 1);
