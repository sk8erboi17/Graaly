declare const playerBrand: unique symbol;
export type PlayerId = string & { readonly [playerBrand]: true };
export function playerId(text: string): PlayerId {
  if (!/^[A-Za-z0-9_]{3,16}$/.test(text)) throw new Error("Invalid player id");
  return text as PlayerId;
}
export function mapValues<T, U>(values: readonly T[], fn: (value: T) => U): U[] {
  return values.map(fn);
}
