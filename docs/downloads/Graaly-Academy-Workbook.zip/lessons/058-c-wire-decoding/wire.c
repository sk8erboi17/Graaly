#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
bool read_be32(const uint8_t *bytes, size_t length, uint32_t *out) {
    if (!bytes || !out || length < 4) return false;
    *out = ((uint32_t)bytes[0] << 24) | ((uint32_t)bytes[1] << 16)
         | ((uint32_t)bytes[2] << 8) | (uint32_t)bytes[3];
    return true;
}
bool consume(uint8_t *bytes, size_t *length, size_t count) {
    if (!bytes || !length || count > *length) return false;
    memmove(bytes, bytes + count, *length - count); *length -= count; return true;
}
