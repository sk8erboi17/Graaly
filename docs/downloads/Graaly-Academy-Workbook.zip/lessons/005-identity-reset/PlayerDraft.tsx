import React, { useState } from "react";
import { ChatInput, Inventory, Item } from "@graaly/react";

function Draft({ playerId }: { playerId: string }) {
  const [note, setNote] = useState("");
  return <ChatInput prompt={"Note for " + playerId} value={note} onChange={setNote} />;
}

export default function PlayerDraft() {
  const [playerId, setPlayerId] = useState("Alex");
  return <>
    <Inventory title="Select profile" rows={3}>
      <Item slot={11} material="SKULL_ITEM" name="Alex" onClick={() => setPlayerId("Alex")} />
      <Item slot={15} material="SKULL_ITEM" name="Sam" onClick={() => setPlayerId("Sam")} />
    </Inventory>
    <Draft key={playerId} playerId={playerId} />
  </>;
}