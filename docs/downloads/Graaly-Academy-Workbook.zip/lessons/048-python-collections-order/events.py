from collections import Counter
from itertools import islice

def summary(events):
    counts = Counter(event["kind"] for event in events)
    return [{"kind": kind, "count": count}
            for kind, count in sorted(counts.items(), key=lambda pair: (-pair[1], pair[0]))]

def first_matching(events, kind, limit):
    selected = (event for event in events if event["kind"] == kind)
    return list(islice(selected, max(0, limit)))
