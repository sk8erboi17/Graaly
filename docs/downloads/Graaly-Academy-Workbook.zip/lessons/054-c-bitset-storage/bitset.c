#include <graaly/bits.h>

size_t enabled_count(void) {
    uint64_t words[2];
    graaly_bitset_t set;
    if (!graaly_bitset_init(&set, words, 2, 70)) return 0;
    if (!graaly_bitset_put(&set, 0, true)) return 0;
    if (!graaly_bitset_put(&set, 69, true)) return 0;
    bool enabled = false;
    if (!graaly_bitset_get(&set, 69, &enabled) || !enabled) return 0;
    return graaly_bitset_count(&set);
}
