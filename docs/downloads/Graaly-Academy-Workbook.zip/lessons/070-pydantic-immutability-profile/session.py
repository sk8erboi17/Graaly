from pydantic import BaseModel, ConfigDict, Field, JsonValue, RootModel

class Session(BaseModel):
    model_config = ConfigDict(frozen=True)
    player: str
    scopes: list[str] = Field(default_factory=list)

class Input(RootModel[JsonValue]): pass
class Output(RootModel[JsonValue]): pass

first, second = Session(player="Alex"), Session(player="Sam")
first.scopes.append("read")
assert second.scopes == []
