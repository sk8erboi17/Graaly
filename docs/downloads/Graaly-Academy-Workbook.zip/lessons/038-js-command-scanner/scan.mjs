export function scan(text) {
  const words = []; let token = "", quote = false, escape = false, started = false;
  for (const character of text) {
    if (escape) { token += character; escape = false; started = true; }
    else if (character === "\\") { escape = true; started = true; }
    else if (character === '"') { quote = !quote; started = true; }
    else if (/\s/u.test(character) && !quote) {
      if (started) words.push(token);
      token = ""; started = false;
    } else { token += character; started = true; }
  }
  if (quote || escape) throw new Error("Unfinished argument");
  if (started) words.push(token);
  return words;
}
