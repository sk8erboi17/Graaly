import React, { useState } from "react";
import { Inventory, Item, Message } from "@graaly/react";

export default function Purchase() {
  const [status, setStatus] = useState<"idle" | "pending" | "done">("idle");
  async function buy() {
    if (status === "pending") return;
    setStatus("pending");
    await Promise.resolve(); // api.purchase(idempotencyKey)
    setStatus("done");
  }
  return <>
    {status === "done" && <Message>&aPurchase committed once</Message>}
    <Inventory title="Safe purchase" rows={3}><Item slot={13} material="DIAMOND"
      name={status === "pending" ? "Working..." : "Buy"} onClick={buy} /></Inventory>
  </>;
}