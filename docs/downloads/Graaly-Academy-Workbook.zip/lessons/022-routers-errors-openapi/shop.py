from fastapi import APIRouter, Header, HTTPException, status
from typing import Annotated
from .schemas import PurchaseRequest, PurchaseResponse
from .services import InsufficientCoins, purchase_item

router = APIRouter(prefix="/v1/shop", tags=["shop"])
IdempotencyKey = Annotated[str, Header(alias="Idempotency-Key", min_length=8)]

@router.post("/purchase", response_model=PurchaseResponse, status_code=201)
async def purchase(command: PurchaseRequest, actor: CanPurchase, session: SessionDep, key: IdempotencyKey):
    try:
        return await purchase_item(session, actor, command, key)
    except InsufficientCoins as error:
        raise HTTPException(status_code=status.HTTP_402_PAYMENT_REQUIRED, detail="Not enough coins") from error