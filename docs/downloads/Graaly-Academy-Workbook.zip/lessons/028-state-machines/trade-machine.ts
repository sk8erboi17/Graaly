type Trade = { id: string; partner: string };
type State = { tag: "idle" } | { tag: "offered"; trade: Trade }
  | { tag: "committing"; trade: Trade } | { tag: "done"; receipt: string }
  | { tag: "failed"; reason: string };
type Event = { type: "OFFER"; trade: Trade } | { type: "ACCEPT" }
  | { type: "COMMITTED"; receipt: string } | { type: "FAILED"; reason: string };

export function transition(state: State, event: Event): State {
  if (state.tag === "idle" && event.type === "OFFER")
    return { tag: "offered", trade: event.trade };
  if (state.tag === "offered" && event.type === "ACCEPT")
    return { tag: "committing", trade: state.trade };
  if (state.tag === "committing" && event.type === "COMMITTED")
    return { tag: "done", receipt: event.receipt };
  if (event.type === "FAILED") return { tag: "failed", reason: event.reason };
  return state;
}