from typing import Annotated, Literal
from pydantic import BaseModel, Field, TypeAdapter

class Move(BaseModel):
    kind: Literal["move"]
    x: float
    z: float

class Chat(BaseModel):
    kind: Literal["chat"]
    text: str = Field(min_length=1)

Event = Annotated[Move | Chat, Field(discriminator="kind")]
event = TypeAdapter(Event).validate_python({"kind": "chat", "text": "Hello"})
assert event.kind == "chat"
