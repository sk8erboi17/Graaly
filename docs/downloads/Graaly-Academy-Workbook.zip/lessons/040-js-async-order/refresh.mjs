export function makeRefresh(fetchPrice, publish) {
  let generation = 0;
  return async sku => {
    const mine = ++generation;
    const result = await fetchPrice(sku);
    if (mine === generation) publish(result);
  };
}
