type Trade = { kind: "open"; revision: number }
  | { kind: "accepted"; revision: number; by: string[] }
  | { kind: "cancelled" };
function unreachable(value: never): never { throw new Error(String(value)); }
export function label(state: Trade): string {
  switch (state.kind) {
    case "open": return "Review offer " + state.revision;
    case "accepted": return state.by.length + " confirmations";
    case "cancelled": return "Cancelled";
    default: return unreachable(state);
  }
}
