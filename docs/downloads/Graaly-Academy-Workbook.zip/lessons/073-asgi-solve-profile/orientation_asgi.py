import json
from inspect import isawaitable

def solve(value):
    return {"yaw": value["yaw"] % 360,
            "pitch": min(90, max(-90, value["pitch"]))}

async def app(scope, receive, send):
    parts = []
    while True:
        frame = await receive(); parts.append(frame.get("body", b""))
        if not frame.get("more_body", False): break
    result = solve(json.loads(b"".join(parts)))
    if isawaitable(result): result = await result
    await send({"type": "http.response.start", "status": 200,
                "headers": [(b"content-type", b"application/json")]})
    await send({"type": "http.response.body", "body": json.dumps(result).encode(), "more_body": False})
