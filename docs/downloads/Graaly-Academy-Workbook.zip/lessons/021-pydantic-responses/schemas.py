from pydantic import BaseModel, Field, model_validator

class Reward(BaseModel):
    material: str
    amount: int = Field(ge=1, le=64)

class PurchaseRequest(BaseModel):
    item: str
    quantity: int = Field(ge=1, le=16)

class SessionRequest(BaseModel):
    player_id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9:_-]{0,35}$")
    player_name: str = Field(pattern=r"^[A-Za-z0-9_]{1,16}$")

    @model_validator(mode="after")
    def limit_rare_stack(self):
        if self.item == "diamond" and self.quantity > 4:
            raise ValueError("diamond quantity cannot exceed four")
        return self