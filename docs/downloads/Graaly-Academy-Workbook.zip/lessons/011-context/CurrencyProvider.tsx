import React, { createContext, useContext, useMemo, useState } from "react";
import { Line, Scoreboard } from "@graaly/react";

const Currency = createContext<{ coins: number } | null>(null);
function Wallet() {
  const value = useContext(Currency);
  if (value === null) throw new Error("Wallet requires Currency.Provider");
  return <Scoreboard title="Wallet"><Line id="coins">Coins: {value.coins}</Line></Scoreboard>;
}
export default function App() {
  const [coins] = useState(150);
  const value = useMemo(() => ({ coins }), [coins]);
  return <Currency.Provider value={value}><Wallet /></Currency.Provider>;
}