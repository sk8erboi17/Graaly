import json, uuid
from contextvars import ContextVar
from time import perf_counter

request_id_var: ContextVar[str] = ContextVar("request_id", default="none")

@app.middleware("http")
async def observe(request, call_next):
    request_id = request.headers.get("x-request-id", str(uuid.uuid4()))
    token = request_id_var.set(request_id)
    started = perf_counter()
    try:
        response = await call_next(request)
        return response
    finally:
        logger.info(json.dumps({"event": "request.completed", "id": request_id,
            "duration_ms": round((perf_counter() - started) * 1000, 2)}))
        request_id_var.reset(token)