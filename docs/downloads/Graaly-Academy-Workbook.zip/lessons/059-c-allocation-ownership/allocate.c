#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
void *allocate_items(size_t count, size_t size) {
    if (size != 0 && count > SIZE_MAX / size) return NULL;
    if (count == 0 || size == 0) return NULL;
    return malloc(count * size);
}
void release_owned(uint32_t *handles, size_t count, void (*release)(uint32_t)) {
    for (size_t i = 0; i < count; ++i) {
        if (!handles[i]) continue;
        uint32_t handle = handles[i];
        for (size_t j = i; j < count; ++j) if (handles[j] == handle) handles[j] = 0;
        release(handle);
    }
}
