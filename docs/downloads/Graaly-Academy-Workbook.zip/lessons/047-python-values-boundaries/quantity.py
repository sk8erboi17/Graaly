def quantity(value):
    if type(value) is not int or not 1 <= value <= 64:
        raise ValueError("quantity must be an integer from 1 to 64")
    return value

def normalize(rows):
    return sorted((dict(row) for row in rows), key=lambda row: row["id"])

assert quantity(2) == 2
try:
    quantity(True)
except ValueError:
    pass
else:
    raise AssertionError("boolean accepted")
