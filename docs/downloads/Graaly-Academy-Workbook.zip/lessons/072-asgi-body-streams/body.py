async def body_bytes(receive, limit=65536):
    parts = []; size = 0
    while True:
        message = await receive()
        if message["type"] == "http.disconnect": raise ConnectionError("disconnected")
        if message["type"] != "http.request": raise ValueError("unexpected frame")
        part = message.get("body", b""); size += len(part)
        if size > limit: raise ValueError("body too large")
        parts.append(part)
        if not message.get("more_body", False): return b"".join(parts)
