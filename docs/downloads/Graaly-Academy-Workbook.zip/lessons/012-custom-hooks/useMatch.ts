import { useSyncExternalStore } from "react";
import { matchStore } from "../state/match-store";

export function useMatch() {
  return useSyncExternalStore(
    matchStore.subscribe,
    matchStore.getSnapshot,
    matchStore.getSnapshot,
  );
}