SELECT sku, SUM(total) AS revenue
FROM orders GROUP BY sku
HAVING SUM(total) >= 1000
ORDER BY revenue DESC, sku ASC;

SELECT id, DENSE_RANK() OVER (ORDER BY coins DESC) AS rank
FROM players ORDER BY rank, id;
