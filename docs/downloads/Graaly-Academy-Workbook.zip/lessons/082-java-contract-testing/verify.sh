npm run generate:c
npm run typecheck:sdk
npm run typecheck:academy
npm run test:academy
# Host compiler parity fixtures are checked by the Academy tests.
# Verify deployed bundles separately on the supported local server matrix.
