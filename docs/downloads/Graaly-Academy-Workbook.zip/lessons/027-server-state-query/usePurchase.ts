import { useMutation, useQueryClient } from "@tanstack/react-query";
const profileKey = (id: string) => ["profile", id] as const;

export function usePurchase(player: PlayerIdentity) {
  const cache = useQueryClient();
  return useMutation({
    mutationFn: (item: ShopItem) => api.purchase({ ...player, item }),
    onMutate: async item => {
      await cache.cancelQueries({ queryKey: profileKey(player.playerId) });
      const previous = cache.getQueryData<Profile>(profileKey(player.playerId));
      if (previous) cache.setQueryData(profileKey(player.playerId),
        { ...previous, coins: previous.coins - price[item] });
      return { previous };
    },
    onError: (_error, _item, context) =>
      cache.setQueryData(profileKey(player.playerId), context?.previous),
    onSettled: () => cache.invalidateQueries({ queryKey: profileKey(player.playerId) }),
  });
}