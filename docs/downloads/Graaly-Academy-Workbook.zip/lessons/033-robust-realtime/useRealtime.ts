function reconnectDelay(attempt: number): number {
  const cap = Math.min(30_000, 500 * 2 ** attempt);
  return Math.floor(cap * (0.5 + Math.random() * 0.5));
}

type StreamState = { lastSequence: number; resumeToken: string | null };

function consume(message: ServerMessage, state: StreamState) {
  if (message.sequence <= state.lastSequence) return state;
  if (message.sequence !== state.lastSequence + 1) return { ...state, resumeToken: null };
  return { lastSequence: message.sequence, resumeToken: message.resumeToken };
}