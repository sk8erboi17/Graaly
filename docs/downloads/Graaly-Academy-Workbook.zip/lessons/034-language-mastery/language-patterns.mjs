// @ts-check
const metadata = new WeakMap();

/** @param {string} prefix */
export function listener(prefix) {
  return player => {
    metadata.set(player, { seenAt: Date.now() });
    queueMicrotask(() => player.sendMessage(prefix + player.name));
  };
}

export async function* pages(load, signal) {
  for (let cursor = null; !signal.aborted;) {
    const page = await load(cursor);
    yield page.items;
    if (page.next === null) return;
    cursor = page.next;
  }
}