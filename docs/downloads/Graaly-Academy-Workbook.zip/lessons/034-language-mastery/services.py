from contextlib import asynccontextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import AsyncIterator, Generic, Protocol, TypeVar
import asyncio

T = TypeVar("T")
request_id: ContextVar[str] = ContextVar("request_id")

class Repository(Protocol, Generic[T]):
    async def get(self, key: str) -> T | None: ...

@dataclass(frozen=True, slots=True)
class Command:
    kind: str
    player_id: str

@asynccontextmanager
async def workers() -> AsyncIterator[asyncio.TaskGroup]:
    async with asyncio.TaskGroup() as group:
        yield group

def route(command: Command) -> str:
    match command:
        case Command(kind="purchase", player_id=player_id): return player_id
        case _: raise ValueError("unknown command")