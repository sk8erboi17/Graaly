SELECT o.id, o.aggregate_id, o.seq
FROM outbox AS o
WHERE o.delivered = 0 AND NOT EXISTS (
  SELECT 1 FROM outbox AS earlier
  WHERE earlier.aggregate_id = o.aggregate_id
    AND earlier.delivered = 0 AND earlier.seq < o.seq
)
ORDER BY o.aggregate_id, o.seq;
