import React, { useState } from "react";
import { ChatInput, Line, Message, Scoreboard } from "@graaly/react";

export default function NicknameFlow() {
  const [nickname, setNickname] = useState("Explorer");
  const [editing, setEditing] = useState(true);
  return <>
    <Scoreboard title="Profile"><Line id="name">Name: {nickname}</Line></Scoreboard>
    {editing ? <ChatInput
      prompt="Type a nickname or cancel" value={nickname}
      onChange={setNickname} onSubmit={value => { setNickname(value); setEditing(false); }}
      onCancel={() => setEditing(false)}
    /> : <Message>&aSaved {nickname}</Message>}
  </>;
}