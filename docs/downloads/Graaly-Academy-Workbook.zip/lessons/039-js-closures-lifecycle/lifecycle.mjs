export function subscribe(bus, onJoin) {
  const seen = new Set();
  const remove = bus.on("join", player => {
    if (!seen.has(player.id)) { seen.add(player.id); onJoin(player); }
  });
  let disposed = false;
  return () => {
    if (disposed) return;
    disposed = true; remove(); seen.clear();
  };
}
