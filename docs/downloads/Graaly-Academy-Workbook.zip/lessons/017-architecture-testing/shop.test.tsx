import React from "react";
import { render } from "@graaly/react-test";
import { Shop } from "./Shop";

test("one click updates the visible balance", async () => {
  const view = await render(<Shop initialCoins={100} />);
  const before = view.commits.length;
  await view.clickSlot(13);
  expect(view.snapshot.scoreboard?.lines[0].text).toContain("60");
  expect(view.commits.length).toBe(before + 1);
});