from contextlib import asynccontextmanager
from time import perf_counter
from fastapi import FastAPI, Request

@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.http = AsyncClient(timeout=5)
    yield
    await app.state.http.aclose()

app = FastAPI(lifespan=lifespan)

@app.middleware("http")
async def timing(request: Request, call_next):
    started = perf_counter()
    response = await call_next(request)
    response.headers["server-timing"] = f"app;dur={(perf_counter() - started) * 1000:.2f}"
    return response