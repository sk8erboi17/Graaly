from decimal import Decimal, ROUND_HALF_UP
from datetime import datetime, timezone

def total(lines):
    value = sum((Decimal(row["price"]) * row["quantity"] for row in lines), Decimal("0"))
    return format(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), ".2f")

def instant(text):
    value = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("timezone required")
    return value.astimezone(timezone.utc)
