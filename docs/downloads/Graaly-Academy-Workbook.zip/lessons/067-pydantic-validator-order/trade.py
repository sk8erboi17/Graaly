from typing import Self
from pydantic import BaseModel, Field, field_validator, model_validator

class Trade(BaseModel):
    sender: str
    recipient: str
    quantity: int = Field(ge=1, le=64)

    @field_validator("sender", "recipient", mode="before")
    @classmethod
    def normalized(cls, value):
        if not isinstance(value, str): raise ValueError("identifier must be text")
        return value.strip().lower()

    @model_validator(mode="after")
    def different_players(self) -> Self:
        if self.sender == self.recipient: raise ValueError("self trade")
        return self
