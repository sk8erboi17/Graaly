package example;
import org.bukkit.plugin.java.JavaPlugin;

public final class AcademyHost extends JavaPlugin {
    @Override public void onEnable() { getLogger().info("Academy host enabled"); }
    @Override public void onDisable() { getLogger().info("Academy host disabled"); }
}
