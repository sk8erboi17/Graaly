from collections.abc import AsyncIterator
from typing import Annotated
from fastapi import Depends, Header, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession

async def get_session(request: Request) -> AsyncIterator[AsyncSession]:
    async with request.app.state.session_factory() as session:
        yield session

async def current_server(request: Request, token: Annotated[str, Header(alias="x-graaly-key")]):
    server = await request.app.state.tokens.find(token)
    if server is None:
        raise HTTPException(401, "Invalid server token")
    return server

SessionDep = Annotated[AsyncSession, Depends(get_session)]
ServerDep = Annotated[ServerIdentity, Depends(current_server)]