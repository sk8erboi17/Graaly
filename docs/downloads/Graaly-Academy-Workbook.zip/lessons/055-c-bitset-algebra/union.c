#include <stdbool.h>
#include <stdint.h>
#include <graaly/bits.h>

bool bitset_union(graaly_bitset_t *out, const graaly_bitset_t *a,
                  const graaly_bitset_t *b) {
    if (!out || !a || !b || out->bit_count != a->bit_count
        || a->bit_count != b->bit_count) return false;
    size_t words = graaly_bitset_word_count(a->bit_count);
    if (words && (!out->words || !a->words || !b->words)) return false;
    for (size_t i = 0; i < words; ++i) out->words[i] = a->words[i] | b->words[i];
    unsigned tail = (unsigned)(a->bit_count % 64u);
    if (tail) out->words[words - 1] &= (UINT64_C(1) << tail) - 1;
    return true;
}
