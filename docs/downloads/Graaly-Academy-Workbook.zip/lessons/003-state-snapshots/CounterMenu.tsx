import React, { useState } from "react";
import { Inventory, Item, Line, Scoreboard } from "@graaly/react";

export default function CounterMenu() {
  const [count, setCount] = useState(0);
  function addThree() {
    setCount(value => value + 1);
    setCount(value => value + 1);
    setCount(value => value + 1);
  }
  return <>
    <Scoreboard title="Render snapshot"><Line id="count">Count: {count}</Line></Scoreboard>
    <Inventory title="Batching" rows={3}>
      <Item slot={13} material="EMERALD" name="Add three" onClick={addThree} />
    </Inventory>
  </>;
}