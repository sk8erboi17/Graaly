class Page(BaseModel, Generic[T]):
    items: list[T]
    next_cursor: str | None

@router.get("/purchases", response_model=Page[PurchaseView])
async def history(actor: CanRead, cursor: str | None = None, limit: int = Query(25, le=100)):
    return await service.page(actor.player_id, cursor=cursor, limit=limit)

async def purchase(command, session):
    async with session.begin():
        result = await apply_purchase(command, session)
        session.add(Outbox(topic="profile.changed", payload=result.event))
    return result