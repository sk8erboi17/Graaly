alembic upgrade head
uvicorn app.main:app --host 127.0.0.1 --port 8000
curl --fail http://127.0.0.1:8000/health
curl --fail http://127.0.0.1:8000/ready
# shift traffic only after readiness succeeds
# restore test is mandatory before calling a backup useful