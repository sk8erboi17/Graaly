import React from "react";
import { Inventory, Item, Message } from "@graaly/react";

const quests = [
  { id: "mine", name: "Mine 32 stone", done: true },
  { id: "fight", name: "Defeat the guardian", done: false },
  { id: "trade", name: "Trade with Alex", done: false },
];

export default function QuestList() {
  const open = quests.filter(quest => !quest.done);
  if (open.length === 0) return <Message>&aAll quests complete</Message>;
  return <Inventory title="Open quests" rows={3}>
    {open.map((quest, index) => <Item
      key={quest.id} slot={10 + index * 2} material="PAPER" name={quest.name}
    />)}
  </Inventory>;
}