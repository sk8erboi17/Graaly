import { useEffect, useState } from "react";
import { websocket } from "graaly";

export function useRealtime(url: string, apiKey: string) {
  const [status, setStatus] = useState<"connecting" | "online" | "offline">("connecting");
  useEffect(() => {
    let disposed = false;
    let connection: Awaited<ReturnType<typeof websocket.connect>> | null = null;
    websocket.connect(url, { headers: { "x-graaly-key": apiKey } }).then(socket => {
      if (disposed) return socket.close();
      connection = socket;
      socket.onMessage(message => consume(JSON.parse(message)));
      socket.onClose(() => setStatus("offline"));
      setStatus("online");
    });
    return () => { disposed = true; if (connection) void connection.close(); };
  }, [url, apiKey]);
  return status;
}