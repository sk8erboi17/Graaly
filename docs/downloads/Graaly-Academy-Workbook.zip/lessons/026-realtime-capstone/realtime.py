from fastapi import Depends, WebSocket, WebSocketDisconnect

@router.websocket("/{player_id}")
async def stream(websocket: WebSocket, player_id: str, _=Depends(require_socket_key)):
    await websocket.accept()
    try:
        while True:
            command = ClientMessage.model_validate(await websocket.receive_json())
            await websocket.send_json(handle(command, player_id).model_dump())
    except WebSocketDisconnect:
        return