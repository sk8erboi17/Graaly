export function quantity(value: unknown): number {
  if (typeof value !== "number" || !Number.isSafeInteger(value)
      || value < 1 || value > 64) throw new Error("Invalid quantity");
  return value;
}
export function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
