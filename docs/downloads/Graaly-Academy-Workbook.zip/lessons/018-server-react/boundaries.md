WEB
request -> server render -> HTML stream -> hydration -> browser events

GRAALY
game event -> React render -> native commit -> game protocol

SHARED
component composition, state, reconciliation, Suspense, transitions