from typing import Annotated
from fastapi import APIRouter, Header, Query
from pydantic import BaseModel, Field

class RenameRequest(BaseModel):
    name: str = Field(min_length=3, max_length=16)

router = APIRouter(prefix="/v1/players", tags=["players"])

@router.put("/{player_id}/name")
async def rename(
    player_id: str,
    command: RenameRequest,
    notify: Annotated[bool, Query()] = True,
    request_id: Annotated[str, Header(alias="x-request-id")] = "",
):
    return {"id": player_id, "name": command.name, "notify": notify}