import React, { useRef } from "react";
import { Inventory, Item, type InventoryHandle } from "@graaly/react";

export default function DismissibleMenu() {
  const menu = useRef<InventoryHandle>(null);
  return <Inventory ref={menu} id="settings" title="Settings" rows={3}>
    <Item slot={13} material="BARRIER" name="Close now"
      onClick={() => menu.current?.dismiss()} />
  </Inventory>;
}