#include <graaly/academy_json.h>
#include <math.h>
J *solve(J *input) {
    double yaw = j_number(j_get(input, j_str("yaw"), j_num(0)));
    double pitch = j_number(j_get(input, j_str("pitch"), j_num(0)));
    yaw = fmod(fmod(yaw, 360.0) + 360.0, 360.0);
    pitch = fmax(-90.0, fmin(90.0, pitch));
    return j_object(2, j_str("yaw"), j_num(yaw), j_str("pitch"), j_num(pitch));
}
