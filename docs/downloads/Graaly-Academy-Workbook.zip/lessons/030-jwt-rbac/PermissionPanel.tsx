const roles = useQuery({ queryKey: ["roles"], queryFn: api.getRoles });
const target = useQuery({ queryKey: ["authorization", targetId], queryFn: () => api.authorization(targetId) });
const update = useMutation({
  mutationFn: (roles: RoleKey[]) => api.setRoles(targetId, roles),
  onSuccess: value => cache.setQueryData(["authorization", targetId], value),
});
return <Inventory title={"Permissions: " + targetName} rows={3}>
  {roles.data?.map(role => <Item key={role.key} name={role.name}
    onClick={() => update.mutate(toggle(target.data!.roles, role.key))} />)}
</Inventory>;