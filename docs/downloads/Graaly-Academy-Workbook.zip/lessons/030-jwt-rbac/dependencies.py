bearer = HTTPBearer(auto_error=False)

async def get_current_actor(credentials: CredentialsDep, session: SessionDep) -> Actor:
    identity = decode_access_token(credentials.credentials, settings.jwt_secret)
    return await resolve_actor(session, identity.player_id)

def require_permission(permission: str):
    async def dependency(actor: Annotated[Actor, Depends(get_current_actor)]):
        if permission not in actor.permissions:
            raise HTTPException(403, f"Missing permission: {permission}")
        return actor
    return dependency