export class Lru {
  #items = new Map();
  constructor(capacity) { this.capacity = Math.max(0, capacity); }
  get(key) {
    if (!this.#items.has(key)) return undefined;
    const value = this.#items.get(key);
    this.#items.delete(key); this.#items.set(key, value); return value;
  }
  put(key, value) {
    this.#items.delete(key); this.#items.set(key, value);
    while (this.#items.size > this.capacity) this.#items.delete(this.#items.keys().next().value);
  }
}
