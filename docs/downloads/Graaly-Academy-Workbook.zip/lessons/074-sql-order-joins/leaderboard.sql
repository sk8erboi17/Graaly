SELECT p.id, p.coins, COUNT(o.id) AS purchases
FROM players AS p
LEFT JOIN orders AS o ON o.player_id = p.id
GROUP BY p.id, p.coins
ORDER BY p.coins DESC, p.id ASC;
