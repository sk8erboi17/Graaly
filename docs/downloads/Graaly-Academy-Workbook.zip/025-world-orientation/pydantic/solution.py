# Normalize a teleport orientation
from graaly_academy import *

def solve_value(input):
    # TODO: implement the requirements without changing input.
    raise NotImplementedError("Implement solve(input)")

from pydantic import RootModel, JsonValue

class Input(RootModel[JsonValue]):
    pass

class Output(RootModel[JsonValue]):
    pass

async def solve(input):
    import inspect
    request = Input.model_validate(input)
    result = solve_value(request.root)
    if inspect.isawaitable(result):
        result = await result
    return Output.model_validate(result).model_dump(mode="json")
