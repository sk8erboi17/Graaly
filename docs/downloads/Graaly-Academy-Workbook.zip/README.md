# Graaly Academy coding workbook

208 Medium and Hard problems across 17 tracks, with 84 lessons.

Open https://sk8erboi17.github.io/Graaly/#academy to edit code, run examples and submit edge tests. Drafts and progress are saved on your device. After an attempt, reveal progressive hints and the explained solution.

Every problem offers JS, TS, Python, C, React (JS/TS), FastAPI, Pydantic, ASGI, Graaly plugin (JS/TS), and HTML/CSS profiles. SQL and YAML have dedicated editors for their query/configuration problems. Each profile folder contains its own execution contract and starter; an untouched starter is deliberately incomplete. Framework profiles execute the actual framework. Pure profiles model the same observable domain behavior.

Coverage: commands, players, events, worlds, entities, tasks, http, compatibility, websocket, packets, ui, config, diagnostics, boards. C includes bitsets, shifts, tagged unions, padding, serialization and ownership. Source examples for all lessons and the helper library sources are included. Java host examples require a local Bukkit server; they are not guest/browser exercises. See runtime-notes.md for build instructions and boundaries.
