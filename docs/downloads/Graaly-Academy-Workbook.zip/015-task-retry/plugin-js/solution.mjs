/** Bound exponential backoff */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}

import { info } from "graaly";
export async function setup(input) {
  const result = await solve(input);
  info(JSON.stringify(result));
}
