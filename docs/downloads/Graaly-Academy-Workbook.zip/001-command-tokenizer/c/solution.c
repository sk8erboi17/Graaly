#include <graaly/academy_json.h>

J *solve(J *input) {
    // TODO: read with j_get; build a result with j_object/j_array.
    academy_error("Implement solve(input)");
    return j_null();
}
