# Quoted command arguments
from graaly_academy import *

def solve(input):
    # TODO: implement the requirements without changing input.
    raise NotImplementedError("Implement solve(input)")

from fastapi import FastAPI, Body
from typing import Any
import inspect
app = FastAPI()

@app.post("/solve")
async def solve_endpoint(input: Any = Body(...)):
    result = solve(input)
    return await result if inspect.isawaitable(result) else result
