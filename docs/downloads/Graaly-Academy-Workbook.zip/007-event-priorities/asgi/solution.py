# Deterministic event priority pipeline
from graaly_academy import *

def solve(input):
    # TODO: implement the requirements without changing input.
    raise NotImplementedError("Implement solve(input)")

import json
import inspect

async def app(scope, receive, send):
    body = b""
    while True:
        frame = await receive()
        body += frame.get("body", b"")
        if not frame.get("more_body", False):
            break
    input = json.loads(body)
    result = solve(input)
    if inspect.isawaitable(result):
        result = await result
    payload = json.dumps(result, allow_nan=False).encode()
    await send({"type": "http.response.start", "status": 200,
                "headers": [(b"content-type", b"application/json")]})
    await send({"type": "http.response.body", "body": payload, "more_body": False})
