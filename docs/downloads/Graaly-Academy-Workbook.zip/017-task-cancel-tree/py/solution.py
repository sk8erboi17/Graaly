# Propagate cancellation through task descendants
from graaly_academy import *

def solve(input):
    # TODO: implement the requirements without changing input.
    raise NotImplementedError("Implement solve(input)")
