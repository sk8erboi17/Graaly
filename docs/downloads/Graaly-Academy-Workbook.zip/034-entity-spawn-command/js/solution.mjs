/** Create and configure an owned entity */
export function solve(input) {
  // TODO: implement the requirements without changing input.
  throw new Error("Not implemented");
}
