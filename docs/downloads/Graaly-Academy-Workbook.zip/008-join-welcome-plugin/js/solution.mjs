/** Welcome only first-time joins */
export function solve(input) {
  // TODO: implement the requirements without changing input.
  throw new Error("Not implemented");
}
