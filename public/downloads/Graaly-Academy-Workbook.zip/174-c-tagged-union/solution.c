int64_t solve(const Packet *packet) {
    /* TODO: implement the contract. */
    return 0;
}
