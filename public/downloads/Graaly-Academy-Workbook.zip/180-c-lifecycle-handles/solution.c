unsigned solve(const uint32_t *handles, size_t count) {
    /* TODO: implement the contract. */
    return 0;
}
