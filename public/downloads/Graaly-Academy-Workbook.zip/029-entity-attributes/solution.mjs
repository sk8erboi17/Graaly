/** Validate entity attributes before configuration */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
