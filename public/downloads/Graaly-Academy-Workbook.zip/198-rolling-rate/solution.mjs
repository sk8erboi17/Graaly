/** Measure a half-open rolling event rate */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
