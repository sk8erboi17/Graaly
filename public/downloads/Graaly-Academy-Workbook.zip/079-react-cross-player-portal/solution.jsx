import React, {useState,useEffect,useRef,useSyncExternalStore,useTransition,useOptimistic,Suspense,lazy}from"react";
import{Inventory,Item,Message,Tab,createRoot,createPortal}from"@graaly/react";
const friend=createRoot({id:"friend",name:"Friend"});

/** Render an owned surface through a cross-player portal */
export default function App(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
