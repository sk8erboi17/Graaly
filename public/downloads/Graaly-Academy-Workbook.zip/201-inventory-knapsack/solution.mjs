/** Maximize reward value within inventory capacity */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
