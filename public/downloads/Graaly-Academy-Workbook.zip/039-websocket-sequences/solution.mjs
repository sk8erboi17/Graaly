/** Buffer out-of-order frames until gaps close */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
