import { events, PlayerJoinEvent } from "graaly";

/** Welcome only first-time joins */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
