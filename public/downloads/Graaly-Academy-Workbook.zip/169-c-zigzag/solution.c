int64_t solve(uint32_t encoded) {
    /* TODO: implement the contract. */
    return 0;
}
