import{packets,tasks,ClientPacket}from"graaly";

/** Schedule a game effect from a network callback */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
