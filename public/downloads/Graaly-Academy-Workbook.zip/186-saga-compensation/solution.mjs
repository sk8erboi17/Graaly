/** Compensate committed saga steps in reverse order */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
