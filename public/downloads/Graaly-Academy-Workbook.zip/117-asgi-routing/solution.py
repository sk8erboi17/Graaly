async def app(scope, receive, send):
    # TODO: implement the HTTP protocol.
    raise NotImplementedError()
