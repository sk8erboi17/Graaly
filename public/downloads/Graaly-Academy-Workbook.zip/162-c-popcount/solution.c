unsigned solve(uint64_t word) {
    /* TODO: implement the contract. */
    return 0;
}
