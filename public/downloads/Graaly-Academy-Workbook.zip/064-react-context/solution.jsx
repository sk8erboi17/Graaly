import React, { useState, useReducer, useMemo, useCallback, useEffect, useRef, createContext, useContext } from "react";
import { Inventory, Item, Message, Scoreboard, Line, BossBar, Tab, ChatInput } from "@graaly/react";
const Coins=createContext(0);
function Wallet(){const coins=useContext(Coins);return <Tab header={"Coins "+coins} footer="Wallet"/>;}

/** Provide coins through context */
export default function App(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
