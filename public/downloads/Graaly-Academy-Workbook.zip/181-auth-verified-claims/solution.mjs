/** Authorize already-verified identity claims */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
