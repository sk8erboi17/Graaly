size_t solve(unsigned query) {
    /* TODO: implement the contract. */
    return 0;
}
