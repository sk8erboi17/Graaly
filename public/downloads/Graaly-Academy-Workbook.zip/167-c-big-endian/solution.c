uint32_t solve(const uint8_t bytes[4]) {
    /* TODO: implement the contract. */
    return 0;
}
