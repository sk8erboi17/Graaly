/** Find a shortest safe path through a block grid */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
