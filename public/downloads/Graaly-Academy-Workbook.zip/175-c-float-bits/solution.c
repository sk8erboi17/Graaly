uint32_t solve(float value) {
    /* TODO: implement the contract. */
    return 0;
}
