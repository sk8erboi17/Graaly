int solve(const char *bytes, size_t capacity) {
    /* TODO: implement the contract. */
    return 0;
}
