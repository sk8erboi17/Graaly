import{commands,worlds}from"graaly";

/** Authorize a world-time command */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
