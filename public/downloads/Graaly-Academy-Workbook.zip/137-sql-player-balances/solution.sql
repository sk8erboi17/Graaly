-- TODO: implement the required query or transaction.
SELECT 1 AS todo;
