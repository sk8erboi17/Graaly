# Graaly Academy coding workbook

208 Medium and Hard problems across 17 tracks.

Open https://sk8erboi17.github.io/Graaly/#academy to edit code, run examples and submit edge tests. Drafts and progress are saved on your device. After submitting your first attempt, reveal progressive hints and the explained solution if needed.

Each folder contains the statement, public examples and a starter for each available language. An untouched starter is deliberately incomplete. The native in-game companion provides 36 theory checkpoints; the browser playground executes the coding exercises.

Coverage: commands, players, events, worlds, entities, tasks, http, compatibility, websocket, packets, ui, config, diagnostics, boards. FastAPI, Pydantic, raw ASGI, HTML/CSS, SQLite, YAML, actual native React tests and C17/WebAssembly are included. C covers bitsets, shifts, tagged unions, padding, serialization and ownership. See the playground execution notes for runtime boundaries.
