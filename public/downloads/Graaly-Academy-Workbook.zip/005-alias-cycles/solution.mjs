/** Resolve command aliases without cycles */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
