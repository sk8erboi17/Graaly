/** Find the highest safe standing location */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
