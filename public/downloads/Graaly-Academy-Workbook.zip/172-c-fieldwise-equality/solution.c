int solve(const Record *a, const Record *b) {
    /* TODO: implement the contract. */
    return 0;
}
