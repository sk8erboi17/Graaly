unsigned solve(uint64_t a, uint64_t b) {
    /* TODO: implement the contract. */
    return 0;
}
