uint64_t solve(uint64_t word, unsigned offset, unsigned width) {
    /* TODO: implement the contract. */
    return 0;
}
