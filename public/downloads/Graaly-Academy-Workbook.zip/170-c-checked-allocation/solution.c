int64_t solve(size_t count, size_t element_size, size_t cap) {
    /* TODO: implement the contract. */
    return 0;
}
