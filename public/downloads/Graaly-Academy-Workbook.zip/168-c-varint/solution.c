int64_t solve(const uint8_t *bytes, size_t size) {
    /* TODO: implement the contract. */
    return 0;
}
