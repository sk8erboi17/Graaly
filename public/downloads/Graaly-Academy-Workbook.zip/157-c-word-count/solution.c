size_t solve(size_t bits) {
    /* TODO: implement the contract. */
    return 0;
}
