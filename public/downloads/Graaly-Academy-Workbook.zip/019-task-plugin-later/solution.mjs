import {commands,tasks} from "graaly";

/** Register delayed work through the real callback contract */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
