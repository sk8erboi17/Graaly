uint32_t solve(uint32_t word, unsigned count) {
    /* TODO: implement the contract. */
    return 0;
}
