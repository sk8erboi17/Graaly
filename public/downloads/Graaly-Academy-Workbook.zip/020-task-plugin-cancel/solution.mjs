import {tasks,players} from "graaly";

/** Cancel a repeating task during plugin teardown */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
