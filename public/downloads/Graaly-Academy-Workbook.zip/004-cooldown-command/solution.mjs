import { commands, players } from "graaly";

/** A command with an exact cooldown */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
