/** Require both parties to accept the current offer revision */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
