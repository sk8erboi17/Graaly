unsigned solve(uint64_t allow, uint64_t deny) {
    /* TODO: implement the contract. */
    return 0;
}
