/** Apply live permission changes to an open session */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
