def solve(input):
    # TODO: implement the data contract.
    raise NotImplementedError()
