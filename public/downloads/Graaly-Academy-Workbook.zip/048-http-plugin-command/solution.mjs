import{commands,http}from"graaly";

/** Fetch an HTTP price in a command callback */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
