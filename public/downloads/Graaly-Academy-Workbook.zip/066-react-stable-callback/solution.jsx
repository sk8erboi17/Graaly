import React, { useState, useReducer, useMemo, useCallback, useEffect, useRef, createContext, useContext } from "react";
import { Inventory, Item, Message, Scoreboard, Line, BossBar, Tab, ChatInput } from "@graaly/react";


/** Keep a callback current when props change */
export default function App(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
