import React, { useState, useReducer, useMemo, useCallback, useEffect, useRef, createContext, useContext } from "react";
import { Inventory, Item, Message, Scoreboard, Line, BossBar, Tab, ChatInput } from "@graaly/react";
function Session({initial}){const [count,setCount]=useState(initial);return <Inventory title={String(count)} rows={1}><Item slot={0} material="STONE" name="Add" onClick={()=>setCount(n=>n+1)}/></Inventory>;}

/** Reset state when the session identity changes */
export default function App(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
