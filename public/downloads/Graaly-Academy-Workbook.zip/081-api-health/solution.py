from fastapi import FastAPI, HTTPException, Depends, Header, Query
from pydantic import BaseModel, Field, ConfigDict

app = FastAPI()

# TODO: declare models, dependencies and async endpoints.
