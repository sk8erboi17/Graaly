size_t solve(size_t head, size_t count, size_t capacity) {
    /* TODO: implement the contract. */
    return 0;
}
