uint64_t solve(uint64_t value, unsigned shift) {
    /* TODO: implement the contract. */
    return 0;
}
