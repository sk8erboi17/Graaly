uint32_t solve(uint32_t current, uint32_t delta) {
    /* TODO: implement the contract. */
    return 0;
}
