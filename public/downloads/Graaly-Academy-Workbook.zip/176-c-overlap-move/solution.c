unsigned solve(size_t destination, size_t source, size_t count) {
    /* TODO: implement the contract. */
    return 0;
}
