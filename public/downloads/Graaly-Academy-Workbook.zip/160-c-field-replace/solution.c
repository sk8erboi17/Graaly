uint32_t solve(uint32_t word, unsigned offset, unsigned width, uint32_t value) {
    /* TODO: implement the contract. */
    return 0;
}
