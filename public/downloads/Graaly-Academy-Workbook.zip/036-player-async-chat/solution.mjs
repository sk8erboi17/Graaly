import{events,tasks,AsyncPlayerChatEvent}from"graaly";

/** Marshal async chat effects onto the server thread */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
