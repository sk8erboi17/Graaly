from pydantic import BaseModel, Field, ValidationError, ConfigDict, field_validator, model_validator
from pydantic import computed_field

class Request(BaseModel):
    # TODO: declare the validated contract.
    pass

def solve(input):
    try:
        model = Request.model_validate(input)
        return {"ok": True, "value": model.model_dump(mode="json")}
    except ValidationError as error:
        return {"ok": False, "errors": [
            {"loc": list(item["loc"]), "type": item["type"]}
            for item in error.errors()
        ]}
