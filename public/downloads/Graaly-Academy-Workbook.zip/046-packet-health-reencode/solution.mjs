import{packets,ServerPacket,WrapperPlayServerUpdateHealth}from"graaly";

/** Reencode an edited outgoing packet */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
