import{entities,worlds,commands}from"graaly";

/** Create and configure an owned entity */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
