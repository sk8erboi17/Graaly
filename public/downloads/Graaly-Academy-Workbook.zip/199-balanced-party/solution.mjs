/** Partition players into the most balanced teams */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
