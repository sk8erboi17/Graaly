unsigned solve(const uint64_t a[2], const uint64_t b[2]) {
    /* TODO: implement the contract. */
    return 0;
}
