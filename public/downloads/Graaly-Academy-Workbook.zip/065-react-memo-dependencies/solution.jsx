import React, { useState, useReducer, useMemo, useCallback, useEffect, useRef, createContext, useContext } from "react";
import { Inventory, Item, Message, Scoreboard, Line, BossBar, Tab, ChatInput } from "@graaly/react";


/** Memoize a total without stale dependencies */
export default function App(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
