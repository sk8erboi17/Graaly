#include <graaly/bits.h>
int solve(size_t bits, const size_t *indices, size_t count) {
    /* TODO: implement the contract. */
    return 0;
}
