/** Calculate exclusive span durations */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
