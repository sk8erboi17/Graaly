/** Convert negative world coordinates to chunks */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
