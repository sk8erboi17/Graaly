import{packets,ClientPacket,WrapperPlayClientChatMessage}from"graaly";

/** Cancel a received chat packet through PacketEvents */
export function setup(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
