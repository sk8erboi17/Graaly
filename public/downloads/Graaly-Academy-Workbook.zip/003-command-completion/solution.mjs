/** Permission-aware tab completion */
export function solve(input) {
  // TODO: implement the requirements.
  throw new Error("Not implemented");
}
