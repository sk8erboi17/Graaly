unsigned solve(uint8_t tag, uint32_t counter) {
    /* TODO: implement the contract. */
    return 0;
}
